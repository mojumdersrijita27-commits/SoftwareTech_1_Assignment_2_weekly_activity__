from PIL import Image

image = Image.open('1_Gammar 2021_1_2021_06_03-13-19-23-898.PNG')
print(image.size)
print(image.filename)
print(image.format)

image = image.transpose(Image.Transpose.ROTATE_90)
image.show()

img_rotated = image.rotate(30)
img_rotated.save('img_rotated.png', 'png')